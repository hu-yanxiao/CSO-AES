from setuptools import setup, find_packages
from Cython.Distutils import build_ext
from setuptools.extension import Extension

# To use a consistent encoding
from codecs import open
from os import path
import numpy as np


mlip_include_dir = [
    "/work/phy-huangj/app/mlip-v9.2.3d/src/common",
    "/work/phy-huangj/app/mlip-v9.2.3d/src",
    "/work/phy-huangj/app/mlip-v9.2.3d/dev_src",
   ## "/opt/intel/compilers_and_libraries_2019.5.281/linux/mkl/include",
]
ext_modules = [
    Extension(
        "pymlip.core._mtp",
        sources=["pysus2mlip/core/_mtp.pyx"],
        include_dirs=[np.get_include()] + mlip_include_dir,
        extra_objects=["/work/phy-huangj/app/mlip-v9.2.3d/lib/lib_mlip_interface.a"],
        extra_compile_args=["-std=c++11"],
  ##      extra_link_args=["-std=c++11", "-L/opt/intel/compilers_and_libraries_2019.5.281/linux/mkl/lib", "-lmkl_rt"],
        extra_link_args=["-std=c++11"],
        language="c++",
    )
]



here = path.abspath(path.dirname(__file__))

# Get the long description from the README file
with open(path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()


version = "0.0.1"
setup(
    name="pymlip",
    version=version,
    description="Pythonic Wrapper to mlip using cython",
    long_description=long_description,
    long_description_content_type="text/markdown",
    # author='',
    # author_email='',
    cmdclass={"build_ext": build_ext},
    ext_modules=ext_modules,
    packages=find_packages(exclude=["docs", "tests"]),
    install_requires=["numpy"],
    extras_require={"all": ["ase"]},
)
