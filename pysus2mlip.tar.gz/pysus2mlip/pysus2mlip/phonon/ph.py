"""
Dynamics calculations using MTP
"""
from pymlip.core import PyConfiguration
from pymlip.core import MTPCalactor
from typing import Optional, Union, List
from phonopy import Phonopy
#from phono3py import Phono3py
from phonopy.interface.calculator import read_crystal_structure
import numpy as  np
from phonopy.units import VaspToTHz
from ase.data import atomic_numbers
from phonopy.file_IO import write_FORCE_CONSTANTS
from phonopy.phonon.band_structure import  get_band_qpoints_by_seekpath
import os
import yaml
from yaml import Loader
import h5py
from ase.io import Trajectory, write,read

#from ._base import Potential
#from ._m3gnet import M3GNet







class Mlip2Phononpy:


    def __init__(self, pos:str="POSCAR",sc_matrix:np=None,distance:float=0.01,potential: str = "p.mtp",unique_numbers: List =None):

        self.unitcell,_ = read_crystal_structure(pos,interface_mode='vasp')
        self.potential=potential
        if sc_matrix.all()==None:
            self.sc_matrix = np.eye(3,dtype=int)*3
        else:
            self.sc_matrix = sc_matrix
        self.distance=distance
        self.phonon=Phonopy(self.unitcell,supercell_matrix=self.sc_matrix,factor=VaspToTHz)
        self.unique_numbers=unique_numbers
        self.SC=[]
        self.FS=[]
        self.mtpcalc=MTPCalactor(self.potential)
        self.phonon.generate_displacements(distance=self.distance)
        self.SC = self.phonon.supercells_with_displacements
    def calc_FS(self):
        for a in self.SC:
            cfg=PyConfiguration.from_ase_atoms(a,unique_numbers=self.unique_numbers)
            self.mtpcalc.calc(cfg)
            self.FS.append(cfg.force)
        self.FS=np.array(self.FS)
        self.phonon.forces = self.FS
        self.phonon.produce_force_constants()
        self.phonon.save()
        write_FORCE_CONSTANTS(self.phonon.force_constants, filename="FORCE_CONSTANTS", p2s_map=None)

    def auto_band_structure(
            self,
            npoints=51,
            with_eigenvectors=True,
            with_group_velocities=True,
            plot=False,
            write_yaml=True,
            filename="band.yaml",
    ):
        """Conveniently calculate and draw band structure.

        Parameters
        ----------
        See docstring of ``Phonopy.run_band_structure`` for the parameters of
        ``with_eigenvectors`` (default is False) and ``with_group_velocities``
        (default is False).

        npoints : int, optional
            Number of q-points in each segment of band struture paths.
            The number includes end points. Default is 101.
        plot : Bool, optional
            With setting True, band structure is plotted using matplotlib and
            the matplotlib module (plt) is returned. To watch the result,
            usually ``show()`` has to be called. Default is False.
        write_yaml : Bool
            With setting True, ``band.yaml`` like file is written out. The
            file name can be specified with the ``filename`` parameter.
            Default is False.
        filename : str, optional
            File name used to write ``band.yaml`` like file. Default is
            ``band.yaml``.

        """
        bands, labels, path_connections = get_band_qpoints_by_seekpath(
            self.phonon._primitive, npoints, is_const_interval=True
        )
        self.phonon.run_band_structure(
            bands,
            with_eigenvectors=with_eigenvectors,
            with_group_velocities=with_group_velocities,
            path_connections=path_connections,
            labels=labels,
            is_legacy_plot=False,
        )
        if write_yaml:
            self.phonon.write_yaml_band_structure(filename=filename)
        if plot:
            return self.plot_band_structure()

    def plot_band_structure(self):
        """Plot calculated band structure.

        Returns
        -------
        matplotlib.pyplot.

        """
        import matplotlib.pyplot as plt
        plt.rcParams['font.family'] = 'Times New Roman'
        plt.rcParams['font.size'] = 10
        if self.phonon._band_structure is None:
            msg = "run_band_structure has to be done."
            raise RuntimeError(msg)

        if self.phonon._band_structure.is_legacy_plot:
            fig, axs = plt.subplots(1, 1)
        else:
            from mpl_toolkits.axes_grid1 import ImageGrid

            n = len([x for x in self.phonon._band_structure.path_connections if not x])
            fig = plt.figure(figsize=(6,4))
            axs = ImageGrid(
                fig,
                111,  # similar to subplot(111)
                nrows_ncols=(1, n),
                axes_pad=0.11,
                label_mode="L",
            )
            frequencies=self.phonon._band_structure._frequencies
            path_connections = self.phonon._band_structure._path_connections
            labels = self.phonon._band_structure._labels
            distances = self.phonon._band_structure._distances
            bp = BandPlot(axs)
            bp.decorate(labels, path_connections, frequencies, distances)
            bp.plot(distances, frequencies, path_connections, fmt=None)
        return plt

    def get_phonon_dispersion(self,write_dat:bool=False):
        plt=self.auto_band_structure(npoints=101,write_yaml=True,plot=True,with_eigenvectors=True,with_group_velocities=True)
       ## plt.show()
        plt.savefig("phonon_dispersion.jpeg",dpi=300)
        if write_dat:
            _write_data("band.yaml")






def _read_band_yaml(filename):
    _, ext = os.path.splitext(filename)
    if ext == ".xz" or ext == ".lzma":
        try:
            import lzma
        except ImportError:
            raise (
                "Reading a lzma compressed file is not supported "
                "by this python version."
            )
        with lzma.open(filename) as f:
            data = yaml.load(f, Loader=Loader)
    elif ext == ".gz":
        import gzip

        with gzip.open(filename) as f:
            data = yaml.load(f, Loader=Loader)
    else:
        with open(filename, "r") as f:
            data = yaml.load(f, Loader=Loader)

    frequencies = []
    distances = []
    qpoints = []
    labels = []
    for j, v in enumerate(data["phonon"]):
        if "label" in v:
            labels.append(v["label"])
        else:
            labels.append(None)
        frequencies.append([f["frequency"] for f in v["band"]])
        qpoints.append(v["q-position"])
        distances.append(v["distance"])

    if "labels" in data:
        labels = data["labels"]
    elif all(x is None for x in labels):
        labels = []

    return (
        np.array(distances),
        np.array(frequencies),
        np.array(qpoints),
        data["segment_nqpoint"],
        labels,
    )
def _write_data(filename):
    bands_data = _read_band_yaml(filename)
    distances = bands_data[0]
    frequencies = bands_data[1]
    segment_nqpoint = bands_data[3]
    end_points = [
        0,
    ]
    for nq in segment_nqpoint:
        end_points.append(nq + end_points[-1])
    end_points[-1] -= 1
    segment_positions = distances[end_points]
    ff=open("B.data","w")
    ff.write("""# End points of segments: """)
   # print("# End points of segments: ")
    ff.write("#   " + "%10.8f " * len(segment_positions) % tuple(segment_positions)+"\n")

    for j, freqs in enumerate(frequencies.T):
        q = 0
        for nq in segment_nqpoint:
            for d, f in zip(
                    distances[q: (q + nq)], freqs[q: (q + nq)] * 1.0
            ):
                ff.write("%f %f" % (d, f)+"\n")
            q += nq
            ff.write("\n")
        ff.write("")
    ff.close()
class BandPlot:
    """Band structure plotting class.

    This class adds band structure plots to Matplotlib axes.

    Attributes
    ----------
    xscale : float
        This is used to scale the plot shape to be nicer. The value
        can be computed using set_xscale as default, which is simply:

            xscale = max_freq / max_dist * 1.5

    """

    def __init__(self, axs):
        """Init method.

        Parameters
        ----------
        axs : Matplotlib axes of ImageGrid, optional
            axs = ImageGrid(fig, 111, nrows_ncols=(1, n), ...)

        """
        self._axs = axs
        self.xscale = None
        self._decorated = False

    def plot(self, distances, frequencies, path_connections, fmt=None, label=None):
        """Plot one band structure.

        If ``labels`` is given, decoration such as horizontal line at freq=0,
        x-label, y-label, and tics are set, which should be done only once.

        distances : list of ndarray
            Distances in reciprocal space.
            See the detail in docstring of Phonopy.get_band_structure_dict.
        frequencies : list of ndarray
            Phonon frequencies.
            See the detail in docstring of Phonopy.get_band_structure_dict.
        path_connections : list of ndarray
            This describes band segments are connected or not.
            See the detail in docstring of Phonopy.run_band_structure.
        fmt : str, optional
            Matplotlib format strings. Default is None, which is equivalent to
            'r-'.
        label : str, optional
            Label attached to band structure.

        """
        if fmt is None:
            _fmt = "r-"
        else:
            _fmt = fmt

        if self.xscale is None:
            self.set_xscale_from_data(frequencies, distances)

        count = 0
        distances_scaled = [d * self.xscale for d in distances]
        for i, (d, f, c) in enumerate(
            zip(distances_scaled, frequencies, path_connections)
        ):
            ax = self._axs[count]
            if i == 0 and label is not None:
                curves = ax.plot(d, f, _fmt, linewidth=1)
                curves[0].set_label(label)
                ax.legend()
            else:
                ax.plot(d, f, _fmt, linewidth=1)
            if not c:
                count += 1

    def set_xscale_from_data(self, frequencies, distances):
        """Set xscale from data."""
        max_freq = max([np.max(fq) for fq in frequencies])
        max_dist = distances[-1][-1]
        self.xscale = max_freq / max_dist * 1.5

    def decorate(self, labels, path_connections, frequencies, distances):
        """Decorate plots.

        Parameters
        ----------
        labels : List of str, optional
            Labels of special points.
            See the detail in docstring of Phonopy.run_band_structure.

        """
        if self._decorated:
            raise RuntimeError("Already BandPlot instance is decorated.")
        else:
            self._decorated = True

        if self.xscale is None:
            self.set_xscale_from_data(frequencies, distances)

        distances_scaled = [d * self.xscale for d in distances]

        # T T T F F -> [[0, 3], [4, 4]]
        lefts = [0]
        rights = []
        for i, c in enumerate(path_connections):
            if not c:
                lefts.append(i + 1)
                rights.append(i)
        seg_indices = [list(range(lft, rgt + 1)) for lft, rgt in zip(lefts, rights)]
        special_points = []
        for indices in seg_indices:
            pts = [distances_scaled[i][0] for i in indices]
            pts.append(distances_scaled[indices[-1]][-1])
            special_points.append(pts)

        self._axs[0].set_ylabel("Frequency (THz)",fontsize=15)
        l_count = 0
        for ax, spts in zip(self._axs, special_points):
            ax.xaxis.set_ticks_position("both")
            ax.yaxis.set_ticks_position("both")
            ax.xaxis.set_tick_params(which="both", direction="in")
            ax.yaxis.set_tick_params(which="both", direction="in")
            ax.set_xlim(spts[0], spts[-1])
            ax.set_xticks(spts)
            if labels is None:
                ax.set_xticklabels(
                    [
                        "",
                    ]
                    * len(spts)
                )
            else:
                ax.set_xticklabels(labels[l_count : (l_count + len(spts))])
                l_count += len(spts)
            ax.plot(
                [spts[0], spts[-1]], [0, 0], linestyle=":", linewidth=0.5, color="b"
            )






