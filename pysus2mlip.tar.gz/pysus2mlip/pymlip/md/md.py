"""
Dynamics calculations using MTP
"""

import contextlib
import io
import time
import pickle
import sys
from typing import Optional, Union, List
from ase.data import atomic_numbers
import numpy as np
from ase import Atoms, units
from ase.calculators.calculator import Calculator, all_changes
from ase.constraints import ExpCellFilter
from ase.io import Trajectory, write,read
from ase.io.trajectory import TrajectoryReader
from ase.md.nptberendsen import NPTBerendsen, Inhomogeneous_NPTBerendsen
from ase.md.nvtberendsen import NVTBerendsen
from ase.md.langevin import Langevin
from ase.md.velocitydistribution import MaxwellBoltzmannDistribution
from ase.optimize.bfgs import BFGS
from ase.optimize.bfgslinesearch import BFGSLineSearch
from ase.optimize.fire import FIRE
from ase.optimize.lbfgs import LBFGS, LBFGSLineSearch
from ase.optimize.mdmin import MDMin
from ase.optimize.optimize import Optimizer
from ase.optimize.sciopt import SciPyFminBFGS, SciPyFminCG
#from pymatgen.core.structure import Molecule, Structure
#from pymatgen.io.ase import AseAtomsAdaptor
from ..core import PyConfiguration
from ..core import MTPCalactor

#from ._base import Potential
#from ._m3gnet import M3GNet

OPTIMIZERS = {
    "FIRE": FIRE,
    "BFGS": BFGS,
    "LBFGS": LBFGS,
    "LBFGSLineSearch": LBFGSLineSearch,
    "MDMin": MDMin,
    "SciPyFminCG": SciPyFminCG,
    "SciPyFminBFGS": SciPyFminBFGS,
    "BFGSLineSearch": BFGSLineSearch,
}


class MTPCalculator(Calculator):
    """
    MTP & SUS2-MLIP calculator based on ase Calculator
    """

    implemented_properties = ["energy",  "forces", "energies" ,"stress"]

    def __init__(self, potential: str = "p.mtp", mtpcalc: MTPCalactor=None, unique_numbers: List =None ,compute_stress: bool = True, stress_weight: float = 1.0,print_EK: bool = True, **kwargs):
        """

        Args:
            potential (str): xxx.mtp
            compute_stress (bool): whether to calculate the stress
            stress_weight (float): the stress weight.
            **kwargs:
        """
        super().__init__(**kwargs)
        self.potential = potential   ##  xxx.mtp
        self.compute_stress = compute_stress
        self.print_EK = print_EK
        self.stress_weight = stress_weight
        self.mtpcalc = MTPCalactor(self.potential)
        self.unique_numbers=unique_numbers

    def calculate(
        self,
        atoms: Optional[Atoms] = None,
        properties: Optional[list] = None,
        system_changes: Optional[list] = None,
        unique_numbers: Optional[list] = None
    ):
        """
        Args:
            atoms (ase.Atoms): ase Atoms object
            properties (list): list of properties to calculate
            system_changes (list): monitor which properties of atoms were
                changed for new calculation. If not, the previous calculation
                results will be loaded.
        Returns:

        """
        properties = properties or ["energy"]
        system_changes = system_changes or all_changes
        super().calculate(atoms=atoms, properties=properties, system_changes=system_changes)

        # graph = self.potential.graph_converter(atoms)
        # graph_list = graph.as_tf().as_list()
        # results = self.potential.get_efs_tensor(graph_list, include_stresses=self.compute_stress)
        cfg=PyConfiguration.from_ase_atoms(atoms,unique_numbers=self.unique_numbers)
       # print(cfg.types)
        V=atoms.cell.volume
        self.mtpcalc.calc(cfg)
        self.results['energy'] = np.array(cfg.energy)
        self.results['forces'] = cfg.force
        self.results['energies'] = np.array(cfg.site_energys)
        print(f"PE:{np.array(cfg.energy):.4f} (ev)")

        if self.compute_stress:
            self.results['stress'] = -np.array([cfg.stresses[0,0],cfg.stresses[1,1],cfg.stresses[2,2],cfg.stresses[1,2],cfg.stresses[0,2],cfg.stresses[0,1]])* self.stress_weight/V


class Relaxer:
    """
    Relaxer is a class for structural relaxation
    """

    def __init__(
        self,
        potential: str = 'p.mtp',
        optimizer: Union[Optimizer, str] = "BFGSLineSearch",
        relax_cell: bool = True,
        unique_numbers: List = None,
        stress_weight: float = 1,
    ):
        """

        Args:
            potential (str): xxx.mtp
            optimizer (str or ase Optimizer): the optimization algorithm.
                Defaults to "FIRE"
            relax_cell (bool): whether to relax the lattice cell
            stress_weight (float): the stress weight for relaxation
        """
        # if isinstance(potential, str):
        #     potential = Potential(M3GNet.load(potential))
        # if potential is None:
        #     potential = Potential(M3GNet.load())

        if isinstance(optimizer, str):
            optimizer_obj = OPTIMIZERS.get(optimizer, None)
        elif optimizer is None:
            raise ValueError("Optimizer cannot be None")
        else:
            optimizer_obj = optimizer

        self.opt_class: Optimizer = optimizer_obj
        self.calculator = MTPCalculator(potential=potential,unique_numbers=unique_numbers ,stress_weight=stress_weight)
        self.relax_cell = relax_cell
        self.potential = potential
       ## self.ase_adaptor = AseAtomsAdaptor()

    def relax(
        self,
        atoms: Atoms,
        fmax: float = 0.001,
        steps: int = 5000,
        traj_file: str = None,
        interval=1,
        verbose=True,
        **kwargs,
    ):
        """

        Args:
            atoms (Atoms): the atoms for relaxation
            fmax (float): total force tolerance for relaxation convergence.
                Here fmax is a sum of force and stress forces
            steps (int): max number of steps for relaxation
            traj_file (str): the trajectory file for saving
            interval (int): the step interval for saving the trajectories
            **kwargs:
        Returns:
        """
      #  if isinstance(atoms, (Structure, Molecule)):
       #     atoms = self.ase_adaptor.get_atoms(atoms)
        atoms.set_calculator(self.calculator)
        stream = sys.stdout if verbose else io.StringIO()
        with contextlib.redirect_stdout(stream):
            obs = TrajectoryObserver(atoms)
            if self.relax_cell:
                atoms = ExpCellFilter(atoms)
            optimizer = self.opt_class(atoms, **kwargs)
            optimizer.attach(obs, interval=interval)
            optimizer.run(fmax=fmax, steps=steps)
            obs()
        if traj_file is not None:
            obs.save(traj_file)
        if isinstance(atoms, ExpCellFilter):
            atoms = atoms.atoms
        write("relaxed.vasp",atoms,format='vasp')
        return {
            "final_structure": atoms,
            "trajectory": obs,
        }


class TrajectoryObserver:
    """
    Trajectory observer is a hook in the relaxation process that saves the
    intermediate structures
    """

    def __init__(self, atoms: Atoms):
        """
        Args:
            atoms (Atoms): the structure to observe
        """
        self.atoms = atoms
       ## self.atoms_list:list[Atoms]=[atoms]
        self.energies: list[float] = []
        self.forces: list[np.ndarray] = []
        self.stresses: list[np.ndarray] = []
        self.atom_positions: list[np.ndarray] = []
        self.cells: list[np.ndarray] = []
        self.head = time.strftime("%Y-%m-%d_%H_%M_%S",time.localtime())
    def __call__(self):
        """
        The logic for saving the properties of an Atoms during the relaxation
        Returns:
        """
        self.energies.append(self.compute_energy())
        self.forces.append(self.atoms.get_forces())
        self.stresses.append(self.atoms.get_stress())
        self.atom_positions.append(self.atoms.get_positions())
        self.cells.append(self.atoms.get_cell()[:])
        write(self.head+"_relax_traj.xyz",self.atoms,format='extxyz',append=True)

    def compute_energy(self) -> float:
        """
        calculate the energy, here we just use the potential energy
        Returns:
        """
        energy = self.atoms.get_potential_energy()
        return energy

    def save(self, filename: str):
        """
        Save the trajectory to file
        Args:
            filename (str): filename to save the trajectory
        Returns:
        """
        with open(filename, "wb") as f:
            pickle.dump(
                {
                    "energy": self.energies,
                    "forces": self.forces,
                    "stresses": self.stresses,
                    "atom_positions": self.atom_positions,
                    "cell": self.cells,
                    "atomic_number": self.atoms.get_atomic_numbers(),
                },
                f,
            )


class MolecularDynamics:
    """
    Molecular dynamics class
    """

    def __init__(
        self,
        atoms: Atoms,
        potential: str = "p.mtp",
        unique_numbers: List = None,
        ensemble: str = "nvt",
        temperature: int = 300,
        timestep: float = 1.0,
        pressure: float = 1.01325 * units.bar,
        taut: Optional[float] = None,
        taup: Optional[float] = None,
        compressibility_au: Optional[float] = 0.0,
        trajectory: Optional[Union[str, Trajectory]] = None,
        logfile: Optional[str] = None,
        loginterval: int = 1,
        append_trajectory: bool = False,
        v_rng: int = 12345
    ):
        """

        Args:
            atoms (Atoms): atoms to run the MD
            potential (Potential): potential for calculating the energy, force,
                stress of the atoms
            ensemble (str): choose from 'nvt' or 'npt'. NPT is not tested,
                use with extra caution
            temperature (float): temperature for MD simulation, in K
            timestep (float): time step in fs
            pressure (float): pressure in eV/A^3
            taut (float): time constant for Berendsen temperature coupling
            taup (float): time constant for pressure coupling
            compressibility_au (float): compressibility of the material in A^3/eV
            trajectory (str or Trajectory): Attach trajectory object
            logfile (str): open this file for recording MD outputs
            loginterval (int): write to log file every interval steps
            append_trajectory (bool): Whether to append to prev trajectory
        """

      #  if isinstance(potential, str):
      #      potential = Potential(M3GNet.load(potential))

     #   if isinstance(atoms, (Structure, Molecule)):
    #        atoms = AseAtomsAdaptor().get_atoms(atoms)

        self.atoms = atoms
        self.temperature= temperature
        self.unique_numbers=unique_numbers
        self.atoms.set_calculator(MTPCalculator(potential=potential,unique_numbers=self.unique_numbers,stress_weight=160.21766208))
        self.ensemble=ensemble
        if taut is None:
            taut = 100 * timestep * units.fs
        if taup is None:
            taup = 1000 * timestep * units.fs

        if ensemble.lower() == "nvt":
            MaxwellBoltzmannDistribution(self.atoms, temperature_K=temperature, rng=np.random.RandomState(v_rng))
            self.dyn = NVTBerendsen(
                self.atoms,
                timestep * units.fs,
                temperature_K=temperature,
                taut=taut,
                trajectory=trajectory,
                logfile=logfile,
                loginterval=loginterval,
                append_trajectory=append_trajectory,
            )
        elif ensemble.lower() == "langevin_dynamics":
            MaxwellBoltzmannDistribution(self.atoms, temperature_K=temperature, rng=np.random.RandomState(v_rng))
            self.dyn = Langevin(
                self.atoms,
                timestep * units.fs,
                communicator=None,
                friction=0.01/units.fs,
                temperature_K=temperature,
                #taut=taut,
                trajectory=trajectory,
                logfile=logfile,
                loginterval=loginterval,
                append_trajectory=append_trajectory,


            )


        elif ensemble.lower() == "npt":
            """

            NPT ensemble default to Inhomogeneous_NPTBerendsen thermo/barostat
            This is a more flexible scheme that fixes three angles of the unit
            cell but allows three lattice parameter to change independently.

            """
            MaxwellBoltzmannDistribution(self.atoms, temperature_K=temperature, rng=np.random.RandomState(v_rng))
            self.dyn = Inhomogeneous_NPTBerendsen(
                self.atoms,
                timestep * units.fs,
                temperature_K=temperature,
                pressure_au=pressure,
                taut=taut,
                taup=taup,
                compressibility_au=compressibility_au,
                trajectory=trajectory,
                logfile=logfile,
                loginterval=loginterval,
                # append_trajectory=append_trajectory,
                # this option is not supported in ASE at this point (I have sent merge request there)
            )

        elif ensemble.lower() == "npt_berendsen":
            """

            This is a similar scheme to the Inhomogeneous_NPTBerendsen.
            This is a less flexible scheme that fixes the shape of the
            cell - three angles are fixed and the ratios between the three
            lattice constants.

            """
            MaxwellBoltzmannDistribution(self.atoms, temperature_K=temperature, rng=np.random.RandomState(v_rng))
            self.dyn = NPTBerendsen(
                self.atoms,
                timestep * units.fs,
                temperature_K=temperature,
                pressure_au=pressure,
                taut=taut,
                taup=taup,
                compressibility_au=compressibility_au,
                trajectory=trajectory,
                logfile=logfile,
                loginterval=loginterval,
                append_trajectory=append_trajectory,
            )

        else:
            raise ValueError("Ensemble not supported")

        self.trajectory = trajectory
        self.logfile = logfile
        self.loginterval = loginterval
        self.timestep = timestep

    def run(self, steps: int):
        """
        Thin wrapper of ase MD run
        Args:
            steps (int): number of MD steps
        Returns:

        """
        print(f"Ensemble: {self.ensemble}\tTemp: {self.temperature}")
        print('\n'+' MD started... '.center(60,'-'))
        s_t=time.time()
        self.dyn.run(steps)
        e_t=time.time()
        print('\n' + ' MD terminated... '.center(60, '-'))
        print(f"run time: {e_t-s_t} s")
        print("writing MD trajectory into traj.xyz")
        a=list(TrajectoryReader(self.trajectory))
        write("traj.xyz",a,format='extxyz')

    def set_atoms(self, atoms: Atoms):
        """
        Set new atoms to run MD
        Args:
            atoms (Atoms): new atoms for running MD

        Returns:

        """
        calculator = self.atoms.calc
        self.atoms = atoms
        self.dyn.atoms = atoms
        self.dyn.atoms.set_calculator(calculator)


