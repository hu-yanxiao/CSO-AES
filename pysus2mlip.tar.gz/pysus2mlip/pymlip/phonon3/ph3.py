"""
Dynamics calculations using MTP
"""
from pymlip.core import PyConfiguration
from pymlip.core import MTPCalactor
from typing import Optional, Union, List
#from phonopy import Phonopy
from phono3py import Phono3py
#from phonopy.interface.calculator import read_crystal_structure
import numpy as  np
#from phonopy.units import VaspToTHz
from ase.data import atomic_numbers
#from phonopy.file_IO import write_FORCE_CONSTANTS
#from phonopy.phonon.band_structure import  get_band_qpoints_by_seekpath
import os
import yaml
from yaml import Loader
import h5py
from ase.io import Trajectory, write,read

#from ._base import Potential
#from ._m3gnet import M3GNet









class Mlip3Phononpy:
    def __init__(self, pos:str="POSCAR",sc_matrix:np=None,distance:float=0.01,potential: str = "p.mtp",unique_numbers: List =None,cutoff:float=6.0):

        self.unitcell,_ = read_crystal_structure(pos,interface_mode='vasp')
        self.potential=potential
        self.cutoff= cutoff
        if sc_matrix.all()==None:
            self.sc_matrix = np.array[3,3,3]
        else:
            self.sc_matrix = sc_matrix
        self.distance=distance
        self.phonon=Phono3py(self.unitcell,supercell_matrix=self.sc_matrix,frequency_factor_to_THz=VaspToTHz,log_level=2)
        self.unique_numbers=unique_numbers
        self.SC=[]
        self.FS=[]
        self.mtpcalc=MTPCalactor(self.potential)
        self.phonon.generate_displacements(distance=self.distance, cutoff_pair_distance=None)
        self.SC_full = self.phonon.supercells_with_displacements
        self.phonon.generate_displacements(distance=self.distance,cutoff_pair_distance=self.cutoff)
        self.SC = self.phonon.supercells_with_displacements
    def calc_FS(self):
        SC_cutoff=[a for a in self.SC if a !=None]
        for a in self.SC_full:
            cfg = PyConfiguration.from_ase_atoms(a, unique_numbers=self.unique_numbers)
            self.mtpcalc.calc(cfg)
            self.FS.append(cfg.force)
        print(f"num of displacement: {len(SC_cutoff)}")
        self.FS=np.array(self.FS)
        self.phonon.forces = self.FS
        self.phonon.produce_fc3()
        self.phonon.save(settings={'force_sets': True,
                 'displacements': True,
                 'force_constants': True,
                 'born_effective_charge': True,
                 'dielectric_constant': True})

    def run_kappa(self,mesh=[15,15,15],temp=[300],is_LBTE=False,calc_mean=False,**kwargs):  ##calc_mean=False
        self.phonon.mesh_numbers=mesh
        self.phonon.init_phph_interaction()
        self.phonon.run_thermal_conductivity(temperatures=temp,write_kappa=True,is_LBTE=is_LBTE,**kwargs)
        if not is_LBTE:
            f=f"kappa-m{mesh[0]}{mesh[1]}{mesh[2]}.hdf5"
            read_kappa(f,calc_mean)



def read_kappa(f,calc_mean=False):
    h5f = f
    h5 = h5py.File(h5f)
    T_ = np.array(h5['temperature'])
    K_rta_ = np.array(h5["kappa"])
    if calc_mean:
        K_out = np.zeros((K_rta_.shape[0], 2))
        for i in range(len(T_)):
            K_out[i, 0] = T_[i]
            K_out[i, 1] = (K_rta_[i, 0] + K_rta_[i, 1] + K_rta_[i, 2]) / 3
    else:
        K_out = np.zeros((K_rta_.shape[0], 4))
        for i in range(len(T_)):
            K_out[i, 0] = T_[i]
            K_out[i, 1] = K_rta_[i, 0]
            K_out[i, 2] = K_rta_[i, 1]
            K_out[i, 3] = K_rta_[i, 2]
    np.savetxt("kappa_rta.out", K_out)







